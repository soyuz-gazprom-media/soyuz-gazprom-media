import jinja2
import aiohttp_jinja2
from aiohttp import web
import pymysql
import pymysql.cursors
import sys
sys.path.append('classes')
sys.path.append('page')
sys.path.append('cnn')
sys.path.append('ajax')
from Site import Site
from page import page
from my_tracks import my_tracks
from free_tracks import free_tracks
from about_product import about_product
from soyuz import soyuz
from test_audio import test_audio
from get_file_ajax import get_file_ajax
from get_track_name_ajax import get_track_name_ajax
# from ajax import get_record_file_ajax


@aiohttp_jinja2.template('page/index.html')
async def index(request):
    # Основной режим вывода содержимого
    SITE = site(request)

    SITE.post = await request.post()

    # Вызов функций по ключу
    functions = {
        '': page.page,
        'my_tracks': my_tracks,
        'free_tracks': free_tracks,
        'about_product': about_product,
        'test_audio': test_audio,
        'soyuz': soyuz,
        'send_file_ajax': get_file_ajax,
        'send_track_name_ajax': get_track_name_ajax
        # 'send_record_file_ajax': get_record_file_ajax.get_record_file_ajax
    }

    if (SITE.p[0] not in functions):
        # Если функция не существует - 404
        raise web.HTTPNotFound()

    # Вызов функции
    r = functions[SITE.p[0]](SITE)

    # Обработка редиректа
    if r and 'redirect' in r:
        return web.HTTPFound(r['redirect'])

    # Обработка ajax
    if r and 'ajax' in r:
        return web.HTTPOk(text=r['ajax'])

    return {'content': SITE.content, 'head': SITE.getHead()}


def site(request):
    SITE = Site()
    path = request.match_info.get('url', '')
    SITE.path = path
    SITE.p = path.split('/')
    i = len(SITE.p)
    while i < 7:
        SITE.p.append('')
        i += 1
    SITE.request = request

    return SITE


app = web.Application(client_max_size=1024**8)
aiohttp_jinja2.setup(app, loader=jinja2.FileSystemLoader('templates'))
app.add_routes([web.static('/lib', 'lib'),
                web.static('/templates', 'templates'),
                web.static('/files', 'files'),
                web.get('/{url:.*}', index),
                web.post('/{url:.*}', index)
            ])

if __name__ == '__main__':
    web.run_app(app, port=8888)

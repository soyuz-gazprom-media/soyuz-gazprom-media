import os

def test_audio(SITE):
    print('Test Audio')
    SITE.addHeadFile('/lib/DAN/DAN.css')
    SITE.addHeadFile('/lib/DAN/DAN.js')
    SITE.addHeadFile('/templates/page/js/templates.js')
    SITE.addHeadFile('/templates/page/js/file.js')

    audio_list = os.listdir('files/test_licensed')

    print(audio_list)

    content = ''
    for audio in audio_list:
        audio_file = f'files/test_licensed/{audio}'
        content += f'<div class="track_item"><div class="track_title">{audio}</div><audio controls=""><source src="files/test_licensed/{audio}" type="audio/wav"></audio></div>'


    SITE.content = f'''
    <div class="wrap_800 text-left">
        <div class="title">Лицензионные треки</div>
        <div class="my_track_container">
        <div class="track_title">Two step from hell - Archangel.wav</div>
        <div class="track_title">Two step from hell - Nero.wav</div>
        <div class="track_title">Two step from hell - Star_sky.wav</div>
        <div class="track_title">Two step from hell - Strehght of a Thousand Men.wav</div>
        <div class="track_title" style="margin-bottom:10px;">Two step from hell - Victory.wav</div>
        <div class="title">Треки для теста</div>
        {content}
        </div>
    </div>
    <div class="company_name"><div>СОЮЗ</div></div>
    '''
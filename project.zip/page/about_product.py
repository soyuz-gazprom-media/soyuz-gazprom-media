def about_product(SITE):
    print('about_product')
    SITE.addHeadFile('/lib/DAN/DAN.css')
    SITE.addHeadFile('/lib/DAN/DAN.js')
    SITE.addHeadFile('/templates/page/js/templates.js')

    # SITE.addHeadFile('/templates/page/js/record.js')
    # SITE.addHeadFile('/templates/page/js/record.js')



    SITE.content = '''
        <div class="wrap_800 text-left">
        <div class="title">О продукте</div>
        <div class="text_container">            
        <p>Система позволяет делать полноценную проверку
        музыкальных композиций на авторские права для 
        дальнейшего использования в медиа-ресурсах.</p>
        </div>
    </div>   

    <div class="company_name"><div>СОЮЗ</div></div>
    '''

import os

def free_tracks(SITE):
    print('free_tracks')
    SITE.addHeadFile('/lib/DAN/DAN.css')
    SITE.addHeadFile('/lib/DAN/DAN.js')
    SITE.addHeadFile('/templates/page/js/templates.js')
    SITE.addHeadFile('/templates/page/js/file.js')

    audio_list = os.listdir('files/free_tracks')

    print(audio_list)

    content = ''
    for audio in audio_list:
        audio_file = f'files/free_tracks/{audio}'
        content += f'<div class="track_item"><div class="track_title">{audio}</div><audio controls=""><source src="files/free_tracks/{audio}" type="audio/wav"></audio></div>'


    SITE.content = f'''
        <div class="wrap_800 text-left">
        <div class="title">Бесплатные треки</div>
        <div class="free_track_container">
        {content}
        </div>
    </div>

    <div class="company_name"><div>СОЮЗ</div></div>
    '''

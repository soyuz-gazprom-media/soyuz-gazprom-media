def soyuz(SITE):
    print('soyuz')
    SITE.addHeadFile('/lib/DAN/DAN.css')
    SITE.addHeadFile('/lib/DAN/DAN.js')
    SITE.addHeadFile('/templates/page/js/templates.js')

    # SITE.addHeadFile('/templates/page/js/record.js')
    # SITE.addHeadFile('/templates/page/js/record.js')



    SITE.content = '''
        <div class="wrap_800 text-left">
        <div class="title">О команде</div>
        <div class="text_container">            
        <p><strong>Борис Хуторной</strong></p>
        <p>Дизайнер UI/UX<br>
        Компетенция: figma, html, 
        css, pyton, java script.</p>
        <br>
        <br>
        <p><strong>Ильдар Бадаев</strong></p>
        <p>Интернет-маркетолог<br>
        Компетенция: трейд маркетинг, контекстная реклама, продукт менеджер, проект менеджер.</p>
        <br>
        <br>
        <p><strong>Алексей Домненко</strong></p>
        <p>Fullstack-разработчик, капитан команды<br>
        Компетенция: pyton, java script, data-science, php, html, css.</p>
        </div>
    </div>

    <div class="company_name"><div>СОЮЗ</div></div>
    '''


import json
from CnnBin import CnnBin
import pandas as pd
import sys
from fuzzywuzzy import fuzz
sys.path.append('classes')


def get_track_name_ajax(SITE):
    print('>>> GET_TRACK_NAME_AJAX')
    CNN = CnnBin()

    # Загрузка файла
    track_name = SITE.post['track_name']

    res_max = 0
    track = ''
    df = pd.read_csv('data/tracks.csv')
    for i, row in df.iterrows():
        res = fuzz.WRatio(track_name, row[1])

        if res > res_max:
            res_max = res
            track = track_name
    print('res_max', res_max)    

    #html = f'<div class="cnn_predicted">1111111111111111</div>'
    if res_max > 90:
        html = f'<div class="cnn_audio"><div>Авторские права найдены</div><div>Использование трека запрещено</div></div>'
        html += f'<div><a href="/free_tracks">Посмотреть бесплатные треки</a></div>'
    else:
        html = f'<div class="cnn_audio"><div>Трек не найден в базе данных</div></div>'
        html += f'<div><a href="/free_tracks">Посмотреть бесплатные треки</a></div>'



    answer = {'answer': 'success', 'content': html}
    return {'ajax': json.dumps(answer)}

import random
import sys
sys.path.append('classes')
from CnnBin import CnnBin
import json
import soundfile

def get_record_file_ajax(SITE):
    print('>>> GET_FILE_RECORD_AJAX')

    files_cnn = 'files/cnn/'  # Директория для сохранения файлов для отображения на html странице.

    # Загрузка файла
    filename = SITE.post['file'].filename
    content = SITE.post['file'].file.read()

    save_file = 'files/cnn/record.wav'
    with open(save_file, 'wb') as f:
        f.write(content)

    # Перекодируем ogg -> wav
    # data, samplerate = soundfile.read('files/cnn/record.webm')
    # soundfile.write('files/cnn/record.wav', data, samplerate)

    CNN = CnnBin()
    data = CNN.predict('files/cnn/record.wav')

    rnd = random.randint(1, 999999)

    # Отдаём ответ в формате html
    html =  f'<div class="cnn_predicted">{data["author_pred"]}</div>'
    html += f'<div class="cnn_acc">Точность предсказания: <span>{data["acc_prc"]}</span>%</div>'
    html += f'<div class="cnn_image"><img src="{files_cnn}chroma.png?{rnd}">c</div>'
    html += f'<div class="cnn_image"><img src="{files_cnn}afr.png?{rnd}"></div>'
    html += f'<div class="cnn_audio"><audio controls><source src="{files_cnn}sample.wav?{rnd}" type="audio/wav"></audio></div>'

    answer = {'answer': 'success', 'content': html}
    return {'ajax': json.dumps(answer)}
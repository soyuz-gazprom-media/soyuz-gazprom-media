from pydub import AudioSegment
import json
from CnnBin import CnnBin
import random
import sys
sys.path.append('classes')


def get_file_ajax(SITE):
    print('>>> GET_FILE_AJAX')
    CNN = CnnBin()

    # Директория для сохранения файлов для отображения на html странице.
    files_cnn = 'files/my_tracks/'

    # Загрузка файла
    filename = SITE.post['file'].filename
    post_file = SITE.post['file'].file.read()

    ext_list = filename.split('.')
    ext = str(ext_list[-1].lower())
    track_name = ext_list[0]

    print(f'РАСШИРЕНИЕ {ext}')

    ext_list = ['wav', 'mp3']

    if ext not in ext_list:
        answer = {'answer': 'success',
            'content': '<div class="cnn_predicted">Файлы подобного типа запрещено загружать!</div>'}
        return {'ajax': json.dumps(answer)}

    save_file = f'files/my_tracks/{track_name}.{ext}'
    test_file = f'files/my_tracks/test/test.wav'

    with open(save_file, 'wb') as f:
        f.write(post_file)

    if ext == 'mp3':
        sound = AudioSegment.from_mp3(save_file)

    if ext == 'wav':
        sound = AudioSegment.from_wav(save_file)

    # Переводим в моно.
    sound = sound.set_channels(1)
    sound.export(test_file, format="wav")

    data = CNN.predict(test_file)

    rnd = random.randint(1, 999999)

    # Отдаём ответ в формате html
    html = f'<div class="cnn_predicted">{data["author_pred"]}</div>'

    # html += f'<div class="cnn_acc">Точность предсказания: <span>{data["acc_prc"]}</span>%<br></div>'
    # html += f'<div class="cnn_image"><img src="{files_cnn}chroma.png?{rnd}">c</div>'
    # html += f'<div class="cnn_image"><img src="{files_cnn}afr.png?{rnd}"></div>'
    # html += f'<div class="cnn_audio"><div>Авторские права найдены</div><div>Использование трека запрещено</div><br><audio controls><source src="{files_cnn}/test/test.wav?{rnd}" type="audio/wav"></audio></div>'

    if data['acc_prc'] > 95:
        html += f'<div class="cnn_audio"><div>Авторские права найдены</div><div>Использование трека запрещено</div></div>'
        html += f'<div><a href="/free_tracks">Посмотреть бесплатные треки</a></div>'
    else:
        html += f'<div class="cnn_audio"><div>Трек не найден в базе данных</div></div>'
        html += f'<div><a href="/free_tracks">Посмотреть бесплатные треки</a></div>'

    answer = {'answer': 'success', 'content': html}
    return {'ajax': json.dumps(answer)}

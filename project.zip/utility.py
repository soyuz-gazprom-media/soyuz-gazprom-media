# Создаёт модель, mp3 -> wav -> csv -> обучение модели -> weight

import sys
sys.path.append('classes')
from CnnBin import CnnBin

# Настройки
MP3_TO_WAV = False  # Конвертация mp3 -> wav
CREATE_WRONG = False  # Создаёт датасет с wrong данными -> 0 в бинарной классификации
WAV_TO_DATASET = False  # Создание датасета
CREATE_MODEL= True   # Обучение модели и создание весов

CNN = CnnBin()

# Создаём файлы wav(моно) из mp3(стерео)
if MP3_TO_WAV:
    CNN.mp3_to_wav()

if CREATE_WRONG:
	CNN.create_wrong()

# Создание датасета csv из wav-файла
if WAV_TO_DATASET:
	CNN.wav_to_dataset()

# Обучение модели на готовом датасете и создание весов
if CREATE_MODEL:
    CNN.create_model()
import os
import time
import random
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
# from IPython.display import Audio
import librosa
import librosa.display
import soundfile
from pydub import AudioSegment

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # INFO and WARNING messages are not printed


class CnnBin:
    def __init__(self):
        # Настройкм
        self.mp3_dir = 'data/audio/mp3'  # Директория образцовых mp3 файлов 
        self.wav_dir = 'data/audio/wav_licensed'  # Директория для wav файлов модели
        self.wav_wrong_dir = 'data/audio/wav_wrong'  # Директория образцовых wav файлов
        self.csv_dir = 'data/csv'  # Директория датасета
        self.model_dir = 'data/model'  # Директория весов модели
        self.data_dir = 'data/'  # Директория, где хранятся данные "authors.csv" на которых обучена модель.
        self.test_dir = 'data/test/'  # Директория в которой находятся фалы для проверки модели.
        self.files_cnn = 'files/my_tracks'  # Директория для сохранения файлов для отображения на html странице.
        self.wrong_parth = 500  # Количество wrong - семплов на трек
        self.epochs = 30  # Количество эпох обучения
        self.bias = 43  # Трек может начинаться с тишины, поэтому делаем смещение self.bias = 43 -> ~= 1 секунду от начала
        self.sample_len = 50  # Длина семпла - количество выборок. (512/22050)*100 ~= 2.32 с. Отрезок аудио, по которому распознаётся трек.
        self.hop_len = 1024  # Длина выборки. Частота дискретизации = 22050. Соответственно выборка будет длинной 512/22050 = 0,0232 с.
        self.accuracy = 0.9  # Порог точности определения, выше этого значения - считаем трек определённым.


    def predict(self, wav_file):
        # Загружаем аудио файл в массив numpy
        wav_np, sr = librosa.load(wav_file)
        print(f'Размер массива: {wav_np.shape}, частота дискретизации: {sr}')

        # Вычисляем хромограмму
        chr = librosa.feature.chroma_stft(y=wav_np, sr=sr, n_fft=2048, hop_length=self.hop_len)

        # Вырезаем отрезок длинной self.hop_len*self.sample_len.
        src_sample = wav_np[0:self.hop_len*self.sample_len]
        
        # Семпл хромограммы из хромограммы трека (массив numpy).
        print('CHR.shape', chr.shape)

        bias = 0  # Смещение от начала трека

        # Если трек длинный - ищем по 3 секунде.
        if chr.shape[0] > 200:
            bias = 150

        chroma = chr[:, bias:bias+self.sample_len]
        print('CHROMA.shape', chroma.shape)


        # Сохраняем семпл, по которому было произведено распознавание.
        soundfile.write(f'{self.files_cnn}/sample.wav', src_sample, sr)

        # Изображение имеет 3 оси - поэтому изменяем размер матрицы.
        chroma_r = chroma.reshape((chroma.shape[0], chroma.shape[1], 1))

        # Добавляем ещё одну ось, т.к. на вход модели можно подать только тензор 4 ранга.
        # Получаем тензор 3 ранга, который потом переведём в тензор 4 ранга
        chroma_tensor = np.expand_dims(chroma_r, axis=0)
        print('Тензор семла', chroma_tensor.shape)

        # Папка с весами модели
        files = os.listdir(self.model_dir)
        # Фильтруем список
        model_list = list(filter(lambda x: x.endswith('.h5'), files))

        predicted = ''
        author_pred = 'Не найдено совпадений'
        acc_prc = 0

        # Загружаем в цикле веса модели
        for model in model_list:
            track_name = model.replace('.h5', '')
            h5_file = f'{self.model_dir}/{model}'

            # Загрузка модели
            model = tf.keras.models.load_model(h5_file)

            # Бинарная классификация
            predicted = model.predict(chroma_tensor)

            # Точность предсказания, %.
            acc_p = round(predicted[0][0]*100, 4)

            print(f"\nПРЕДСКАЗАНИЕ: {track_name} = {acc_p}%")
            print(f"Точность: {predicted[0][0]}\n")

            # Считаем трек предсказанным, если точность выше 0.9.
            if acc_p > 95:
                author_pred = track_name
                acc_prc = acc_p
                

        data = {
            'author_pred': author_pred,
            'acc_prc': acc_prc,
        }

        return data



    # Предсказание трека по аудиофайлу
    def predict_old(self, audio_file):
        # Загружаем данные авторов для классификации по ним.
        # id и порядковый номер - не совпадают. Автора определяем по id.
        df = pd.read_csv(self.data_dir + 'authors.csv')

        # Загружаем аудио файл в массив numpy
        audio_np, sr = librosa.load(audio_file)
        print(f'Размер массива: {audio_np.shape}, частота дискретизации: {sr}')

        # Вычисляем хромограмму
        chr = librosa.feature.chroma_stft(y=audio_np, sr=sr, n_fft=2048, hop_length=self.hop_len)

        # Выделяем семпл
        # Вырезаем отрезок длинной self.hop_len*self.sample_len.
        audio_sample = audio_np[0:self.hop_len*self.sample_len] 
        sample = chr[:, 0:self.sample_len]  # Семпл из хромограммы.

        # Сохраняем семпл, по которому было произведено распознавание.
        # soundfile.write(f'{self.files_cnn}/sample.wav', audio_sample, sr)

        # Изображение имеет 3 оси - поэтому изменяем размер матрицы.
        sample_r = sample.reshape((sample.shape[0], sample.shape[1], 1))

        # Добавляем ещё одну ось, т.к. на вход модели можно подать только тензор 4 ранга.
        sample_tensor = np.expand_dims(sample_r, axis=0)
        print('Тензор семла', sample_tensor.shape)

        # Засекаем время выполнения.
        start_time = time.time()

        # Загрузка модели
        model = tf.keras.models.load_model(self.model_file)

        # Классификация данных, предсказание.
        predicted = model.predict(sample_tensor)
        print('PREDICT:', predicted)

        # Максимальный аргумент.
        i = np.argmax(predicted)

        # Точность предсказания.
        acc = predicted[0, i]

        # Точность предсказания, %.
        acc_prc = round(acc*100, 4)
        print(f'Точность: {acc_prc}%')

        # Считаем трек предсказанным, если точность выше 0.9.
        if acc > 0.9:
            author_pred = df.iloc[i,1]
            print("======= ПРЕДСКАЗАНО =======")
            print(author_pred)
        else:
            author_pred = 'Не найдено совпадений'
            print("======= НЕ НАЙДЕНО =======")

        # Время поиска композиции.
        delta_time = round((time.time() - start_time), 2)

        # Создаем и сохраняем изображение хромограммы.
        fig, ax = plt.subplots()
        ax.set_title('Хромограмма семпла', fontsize=16)
        ax.set_xlabel('Выборки по времени, N', fontsize=12)
        ax.set_ylabel('Частота', fontsize=12)
        ax.set_ylim([0,12])
        im = ax.imshow(sample_tensor[0])
        fig.colorbar(im)
        fig.savefig(self.files_cnn + 'chroma.png')

        # АЧХ семпла.
        fig, ax = plt.subplots()
        ax.set_title('Амплитудно - частотная характеристика', fontsize=16)
        ax.set_xlabel('Время, с', fontsize=12)
        ax.set_ylabel('Амплитуда', fontsize=12)
        ax.set_xticks(())
        ax.plot(audio_sample)
        ax.figure.savefig(self.files_cnn + 'afr.png')

        data = {
            'author_pred': author_pred,
            'acc_prc': acc_prc,
            'delta_time': delta_time
        }

        return data



    # Создаём файлы формата wav(моно) из mp3(стерео)
    def mp3_to_wav(self):
        print("\n----- MP3_TO_WAV -----")

        files = os.listdir(self.mp3_dir)
        # Фильтруем список
        mp3_list = list(filter(lambda x: x.endswith('.mp3'), files))
        
        print(mp3_list)

        for mp3 in mp3_list:
            mp3_file = f'{self.mp3_dir}/{mp3}'
            wav_file = f'{self.wav_wrong_dir}/' + mp3.replace('.mp3', '.wav')
            # wav to mp3                                       
            sound = AudioSegment.from_mp3(mp3_file)
            sound = sound.set_channels(1)
            print(f'--- {wav_file} ---')
            sound.export(wav_file, format="wav")

        print('----- Преобразование mp3 в wav завершено -----')
        


    # Создаёт датасет с wrong - данными
    def create_wrong(self):
        print("\n----- CREATE_WRONG -----")

        files = os.listdir(self.wav_wrong_dir)
        wav_list = list(filter(lambda x: x.endswith('.wav'), files))
        wav_list_len = len(wav_list)

        # Если длина списка больше 100 треков - ограничим 100 треков
        if wav_list_len > 100:
            wav_list = wav_list[0:100]

        x_list = []
        y_list = []

        # Перебираем треки
        print("\n----- Перебираем WRONG треки -----")    
        for wav in wav_list:
            wav_file = self.wav_wrong_dir + '/' + wav
            print(f'--- {wav_file} ---')

            # Загружаем трек
            wav_np, sr = librosa.load(wav_file)

            # Вычисляем хромограмму для перебираемого wrong трека
            chr = librosa.feature.chroma_stft(y=wav_np, sr=sr, n_fft=2048, hop_length=self.hop_len)

            # Максимальное значение случайной позиции семпла в треке
            max_rnd = chr.shape[1] - self.sample_len - 1

            # Внутри трека берём self.wrong_parth случайных семплов
            for i in range(self.wrong_parth):
                # Берём случайный трек, но не сначала (что бы не попасть на паузу)
                rnd = random.randint(i, max_rnd)
                sample = chr[:, rnd:rnd + self.sample_len]
                x_list.append(sample.tolist())
                y_list.append(0)  # Для рандомных треков y = 0

        x_arr = np.array(x_list)
        print(f"\n----- {wav}, X_ARR {x_arr.shape} -----")
        print("\n")

        x_arr_r = x_arr.reshape(x_arr.shape[0], 12*self.sample_len)
        x_df = pd.DataFrame(x_arr_r)
        y_df = pd.DataFrame(y_list)

        print("SHAPE", x_df.shape, y_df.shape)

        # Имена файлов и пути до файлов датасета
        x_file = f'{self.csv_dir}/wrong_X.csv'
        y_file = f'{self.csv_dir}/wrong_Y.csv'

        # Сохраняем датасет
        x_df.to_csv(x_file, index=False, encoding='utf-8')
        y_df.to_csv(y_file, index=False, encoding='utf-8')



    # Создание датасета csv из wav-файла
    def wav_to_dataset(self):
        print("\n----- WAV_TO_DATASET -----")

        files = os.listdir(self.wav_dir)
        wav_list = list(filter(lambda x: x.endswith('.wav'), files))

        wrong_x_list, wrong_y_list = self.__get_wrong_wav()

        print('--- NEXT ---', wav_list)

        # Перебираем все треки
        for wav in wav_list:
            x_list = []
            y_list = []

            wav_file = f'{self.wav_dir}/{wav}'
            print(f'--- {wav_file} ---')
            # wav_np - массив numpy, sr - частота дискредитации
            wav_np, sr = librosa.load(wav_file)

            # Вычисляем хромограмму для текущего трека
            chr = librosa.feature.chroma_stft(y=wav_np, sr=sr, n_fft=2048, hop_length=self.hop_len)  # n_fft=2048 - параметр ряда Фурье
            print(f'--- shape {chr.shape} ---')

            # Создаём первую часть датасета - список семплов с верными ответами бинарной классификации для текущего трека
            x_list, y_list = self.__get_current_wav(chr, x_list, y_list)
            print(f'--- Длина current x_list: {len(x_list)}, y_list: {len(y_list)} ---')

            # Создаём вторую часть датасета - список семплов с неверными ответами бинарной классификации из других треков - рандомно
            x_list.extend(wrong_x_list)
            y_list.extend(wrong_y_list)

            print(f'--- Длина FULL x_list: {len(x_list)}, y_list: {len(y_list)} ---')

            x_arr = np.array(x_list, dtype=np.float32)
            y_arr = np.array(y_list, dtype=np.float32)
            print(f"\n----- {wav}, X_ARR {x_arr.shape} -----")

            x_arr_r = x_arr.reshape(x_arr.shape[0], 12*self.sample_len)
            x_df = pd.DataFrame(x_arr_r)
            y_df = pd.DataFrame(y_list)

            print("INFO", x_df.info(), y_df.info())

            # Имена файлов и пути до файлов датасета
            x_name = wav.replace('.wav', ' X.csv')
            y_name = wav.replace('.wav', ' Y.csv')
            x_csv_file = self.csv_dir + '/' + x_name
            y_csv_file = self.csv_dir + '/' + y_name

            # Сохраняем датасет
            x_df.to_csv(x_csv_file, index=False, encoding='utf-8')
            y_df.to_csv(y_csv_file, index=False, encoding='utf-8')



    # Обучение модели на готовом датасете
    def create_model(self):
        print("\n----- CREATE MODEL -----")
        files = os.listdir(self.csv_dir)
        # Создаём список только их "X" файлов. "Y" определяется на основании "X"
        csv_X_list = list(filter(lambda x: x.endswith('X.csv'), files))

        # Удаляем из списка wrong файл
        if 'wrong_X.csv' in csv_X_list:
            csv_X_list.remove('wrong_X.csv')

        for csv_X in csv_X_list:
            csv_X_file = f'{self.csv_dir}/{csv_X}'
            print(f'--- {csv_X_file} ---')

            x_df = pd.read_csv(csv_X_file, dtype=np.float32)
            x_arr = np.array(x_df)

            csv_Y_file = csv_X_file.replace('X.csv', 'Y.csv')

            y_df = pd.read_csv(csv_Y_file)
            y_arr = np.array(y_df, dtype=np.float32)

            x_arr_r = x_arr.reshape((x_arr.shape[0], 12, self.sample_len, 1))
            print('X_ARR_R[10]', x_arr_r.shape, x_arr_r[10])

            # Разбиваем набор на тренировочный и валидационный
            X_train, X_test, Y_train, Y_test = train_test_split(x_arr_r, y_arr, random_state=42, test_size=0.2)

            print('Y_test', Y_test)

            # Переводим 
            # Y_train = tf.keras.utils.to_categorical(Y_train)
            # Y_test = tf.keras.utils.to_categorical(Y_test)

            print('Y_test_CAT', Y_test)

            # Получаем модель CNN
            model = self.model()

            # Имя трека - для сохранения весов
            name = csv_X.replace('X.csv', '')

            # Обучаем модель
            self.fit(model, name, X_train, X_test, Y_train, Y_test)



    # Модель CNN
    def model(self):
        model = tf.keras.Sequential()
        model.add(layers.Conv2D(64, (3, 3), activation='relu', input_shape=((12, self.sample_len, 1))))
        model.add(layers.MaxPooling2D((2, 2)))
        model.add(layers.Conv2D(64, (3, 3), activation='relu'))
        model.add(layers.Flatten())
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(1, activation='sigmoid'))

        model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])

        return model



    # Обучение модели
    def fit(self, model, name, X_train, X_test, Y_train, Y_test):
        print(f'--- Оучение модели, Train.shape: {X_train.shape} {Y_train.shape} Test.shape: {X_test.shape} {Y_test.shape} ---')
        history = model.fit(X_train, Y_train, epochs=self.epochs, batch_size=64)

        # Оцениваем модель
        test_loss, test_acc = model.evaluate(X_test, Y_test)

        file = f'{self.model_dir}/{name}.h5'

        # Сохраним всю модель в  HDF5 файл
        model.save(file)


    # Создаём список семплов с верными ответами бинарной классификации для текущего трека
    def __get_current_wav(self, chr, x_list, y_list):
        # Создаём семплы - отрезки длинной self.sample_len со сдвигом на одну хромограмму от начала и до конца хромограммы
        # Трек может начинаться с тишины, поэтому делаем смещение self.bias ~= 1 секунду от начала
        for i in range(self.bias, chr.shape[1], 1):
            sample = chr[:, i:i+self.sample_len]

            # Если конец хромограммы (sample.shape[1] < self.sample_len) - прерываем
            if sample.shape[1] < self.sample_len:
                break

            x_list.append(sample.tolist())  # numpy в список - быстрее работает с .append()
            y_list.append(1)  # Для текущего трека в бинарной классификации y = 1, для рандомных треков y = 0

        return x_list, y_list


    # Создаём список семплов с неверными ответами бинарной классификации из других треков - рандомно
    def __get_wrong_wav(self):
        print('--- __get_wrong_wav ---')
        files = os.listdir(self.csv_dir)
        csv_list = list(filter(lambda x: x.endswith('.csv'), files))

        if not 'wrong_X.csv' in csv_list:
            self.create_wrong()

        wrong_X_arr = pd.read_csv(f'{self.csv_dir}/wrong_X.csv').to_numpy()
        wrong_Y_arr = pd.read_csv(f'{self.csv_dir}/wrong_Y.csv').to_numpy()

        wrong_X_arr_r = wrong_X_arr.reshape((wrong_X_arr.shape[0], 12, self.sample_len))
        wrong_Y_arr_r = wrong_Y_arr.reshape((wrong_Y_arr.shape[0]))

        x_list = wrong_X_arr_r.tolist()
        y_list = wrong_Y_arr_r.tolist()

        return x_list, y_list
